﻿using System;

namespace WhileLoops
{
    /// <summary>
    /// While Loops lecture code
    /// </summary>
    class MainClass
    {
        /// <summary>
        /// Demonstrates while loops
        /// </summary>
        /// <param name="args">command-line arguments</param>
        public static void Main(string[] args)
        {
            // prompt for and get level
            Console.Write("What level are you in WoW (1-110)? ");
            int level = int.Parse(Console.ReadLine());

            // input validation
            while (level < 1 ||
                level > 110)
            {
                // print error message and reprompt
                Console.WriteLine();
                Console.WriteLine("Level must be between 1 and 110");
                Console.Write("What level are you in WoW (1-110)? ");
                level = int.Parse(Console.ReadLine());
            }

            // print level
            Console.WriteLine();
            Console.WriteLine("Got it, you're level " + level);

            Console.WriteLine();
        }
    }
}
