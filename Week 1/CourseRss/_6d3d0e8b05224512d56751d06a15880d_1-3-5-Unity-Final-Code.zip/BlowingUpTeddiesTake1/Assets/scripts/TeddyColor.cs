﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// An enumeration of the teddy bear colors
/// </summary>
public enum TeddyColor
{
	Green,
	Purple,
	Yellow
}
