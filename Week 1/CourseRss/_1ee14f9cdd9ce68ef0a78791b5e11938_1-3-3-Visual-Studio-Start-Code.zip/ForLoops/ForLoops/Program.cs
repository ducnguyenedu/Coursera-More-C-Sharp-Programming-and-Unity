﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForLoops
{
    /// <summary>
    /// For Loops lecture code
    /// </summary>
    class Program
    {
        /// <summary>
        /// Demonstrates for loops
        /// </summary>
        /// <param name="args">command-line arguments</param>
        static void Main(string[] args)
        {
            Console.WriteLine();
        }
    }
}
