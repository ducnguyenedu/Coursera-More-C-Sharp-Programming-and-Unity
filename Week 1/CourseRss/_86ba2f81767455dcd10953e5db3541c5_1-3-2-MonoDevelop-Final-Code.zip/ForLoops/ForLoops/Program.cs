﻿using System;

namespace ForLoops
{
    /// <summary>
    /// For Loops lecture code
    /// </summary>
    class MainClass
    {
        /// <summary>
        /// Demonstrates for loops
        /// </summary>
        /// <param name="args">command-line arguments</param>
        public static void Main(string[] args)
        {
            Console.WriteLine();
        }
    }
}
