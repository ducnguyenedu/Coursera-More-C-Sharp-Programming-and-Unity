﻿using System;

namespace Methods
{
    /// <summary>
    /// An enumeration for card suits
    /// </summary>
    public enum Suit
    {
        Clubs,
        Diamonds,
        Hearts,
        Spades
    }
}