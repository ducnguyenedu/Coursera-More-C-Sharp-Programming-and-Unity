﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringBasics
{
    /// <summary>
    /// String Basics lecture code
    /// </summary>
    class Program
    {
        /// <summary>
        /// Desmonstrates string basics
        /// </summary>
        /// <param name="args">command-line arguments</param>
        static void Main(string[] args)
        {
            // prompt for and read in gamertag


            // prompt for and read in high score


            // extract the first character of the gamertag


            // print out values


            Console.WriteLine();
        }
    }
}

