﻿using System;

namespace StringBasics
{
    /// <summary>
    /// String Basics lecture code
    /// </summary>
    class MainClass
    {
        /// <summary>
        /// Desmonstrates string basics
        /// </summary>
        /// <param name="args">command-line arguments</param>
        public static void Main(string[] args)
        {
            // prompt for and read in gamertag


            // prompt for and read in high score


            // extract the first character of the gamertag

        
            // print out values


            Console.WriteLine();
        }
    }
}
