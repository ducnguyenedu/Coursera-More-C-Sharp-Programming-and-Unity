﻿using System;

namespace StringBasics
{
    /// <summary>
    /// String Basics lecture code
    /// </summary>
    class MainClass
    {
        /// <summary>
        /// Demonstrates string basics
        /// </summary>
        /// <param name="args">command-line arguments</param>
        public static void Main(string[] args)
        {
            // prompt for and read in gamertag
            Console.Write("Enter gamertag: ");
            string gamertag = Console.ReadLine();

            // prompt for and read in high score
            Console.Write("Enter high score as a whole number: ");
            int highScore = int.Parse(Console.ReadLine());

            // extract the first character of the gamertag
            char firstGamertagCharacter = gamertag[0];
        
            // print out values
            Console.WriteLine();
            Console.WriteLine("Gamertag: " + gamertag);
            Console.WriteLine("High Score: " + highScore);
            Console.WriteLine("First Gamertag Character: " +
                firstGamertagCharacter);

            Console.WriteLine();
        }
    }
}
