﻿using System;

namespace StringOperations
{
    /// <summary>
    /// String Operations lecture code
    /// </summary>
    class MainClass
    {
        /// <summary>
        /// Demonstrates IndexOf and Substring methods
        /// </summary>
        /// <param name="args">command-line arguments</param>
        public static void Main(string[] args)
        {
            // read in csv string


            // find comma location


            // extract name and percent


            // print name and percent


            Console.WriteLine();
        }
    }
}
