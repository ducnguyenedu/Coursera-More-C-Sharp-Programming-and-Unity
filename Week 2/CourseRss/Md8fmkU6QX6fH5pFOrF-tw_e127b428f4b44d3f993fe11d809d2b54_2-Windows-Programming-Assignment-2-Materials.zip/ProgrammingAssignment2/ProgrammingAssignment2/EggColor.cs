﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgrammingAssignment2
{
    /// <summary>
    /// An enumeration of the different egg colors
    /// </summary>
    public enum EggColor
    {
        Blue,
        Brown,
        White
    }
}
