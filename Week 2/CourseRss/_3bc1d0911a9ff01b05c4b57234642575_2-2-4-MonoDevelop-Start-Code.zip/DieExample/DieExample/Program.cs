﻿using System;

namespace DieExample
{
    /// <summary>
    /// Demonstrates testing a Die class
    /// </summary>
    class MainClass
    {
        /// <summary>
        /// Tests the die class
        /// </summary>
        /// <param name="args">command-line arguments</param>
        public static void Main(string[] args)
        {
            Console.WriteLine();
        }
    }
}
