﻿using System;

namespace DieExample
{
    /// <summary>
    /// Demonstrates testing a Die class
    /// </summary>
    class MainClass
    {
        /// <summary>
        /// Tests the die class
        /// </summary>
        /// <param name="args">command-line arguments</param>
        public static void Main(string[] args)
        {
            // test standard die
            Die standardDie = new Die();
            Console.WriteLine("Standard Die");
            Console.WriteLine("------------");
            Console.WriteLine("Number of sides: " + standardDie.NumSides);
            Console.WriteLine("Top side: " + standardDie.TopSide);  

            Console.WriteLine();
        }
    }
}
