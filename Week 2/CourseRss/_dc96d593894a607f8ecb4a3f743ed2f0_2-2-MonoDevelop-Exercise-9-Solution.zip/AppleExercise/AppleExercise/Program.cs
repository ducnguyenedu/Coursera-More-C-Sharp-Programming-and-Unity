﻿using System;

namespace AppleExercise
{
    /// <summary>
    /// Exercise 9, 10, and 11 solution
    /// </summary>
    class MainClass
    {
        /// <summary>
        /// Tests the apple class
        /// </summary>
        /// <param name="args">command-line arguments</param>
        public static void Main (string[] args)
        {
            Console.WriteLine ();
        }
    }
}
